<?php
    $title = 'Compression';
    require_once 'includes/header.php';
    //require_once 'db/conn.php';
    //$result = $crud->getSpecialties();

?>
<p class="text-primary font-weight-bold ">
<h1>COMPRESSION HOSIERY</h1>
<h2>Medical grade compression garments help many patients effectively improve on the venous and lymphatic blood flow of the lower extremities
 and are used to prevent and treat poor circulation. Compression garments help relieve and 
 control edema, swelling, varicose veins, leg fatigue and other problematic leg conditions.<h2>



<h2>The staff at Paradise Physiotherapy is trained to fit your custom hosiery product and decide which would be the best product for you.</h2>
</p>
    <?php require_once 'includes/footer.php'; ?>