<?php
    $title = 'Our Team';
    require_once 'includes/header.php';
    //require_once 'db/conn.php';
   // $result = $crud->getSpecialties();

?>

  <div class="team-boxed">
        <div class="container">
            
            <div class="intro">
                <h2 class="text-center">Team </h2>
                <p class="text-center">Our multidisciplinary team at your service</p>
            </div>
            <div class="row people">
                <div class="col-md-6 col-lg-6 item">
                    <div class="box"><img class="rounded-circle" src="img/1.jpg">
                        <h3 class="name">Salesman</h3>
                        <p class="title">Director</p>
                        <p class="description">Aenean tortor est, vulputate quis leo in, vehicula rhoncus lacus. Praesent aliquam in tellus eu gravida. Aliquam varius finibus est, et interdum justo suscipit id. Etiam dictum feugiat tellus, a semper massa. </p>
                        <div class="social"><a href="#"><i class="fa fa-facebook-official"></i></a><a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-instagram"></i></a></div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 item">
                    <div class="box"><img class="rounded-circle" src="img/2.jpg">
                        <h3 class="name">Wendy</h3>
                        <p class="title">Managing Director</p>
                        <p class="description">Aenean tortor est, vulputate quis leo in, vehicula rhoncus lacus. Praesent aliquam in tellus eu gravida. Aliquam varius finibus est, et interdum justo suscipit id. Etiam dictum feugiat tellus, a semper massa. </p>
                        <div class="social"><a href="#"><i class="fa fa-facebook-official"></i></a><a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-instagram"></i></a></div>
                    </div>
                </div>
            </div>
        </div>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bs-animation.js"></script>
    <script src="js/current-day.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.1.1/aos.js"></script>







    <?php require_once 'includes/footer.php'; ?>